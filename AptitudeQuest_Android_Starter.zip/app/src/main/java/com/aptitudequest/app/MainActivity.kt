package com.aptitudequest.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Question(
    val subject: String,
    val text: String,
    val options: List<String>,
    val answer: Int,
    val explanation: String
)

val questions = listOf(
    Question("Quant", "What is 25% of 240?", listOf("50", "60", "70", "80"), 1,
        "25% = 1/4. So 240 ÷ 4 = 60."),
    Question("Quant", "A number is increased from 200 to 250. What is the percentage increase?", listOf("20%", "25%", "30%", "50%"), 1,
        "Increase = 50. Percentage increase = 50/200 × 100 = 25%."),
    Question("Reasoning", "Find the next number: 2, 6, 12, 20, 30, ?", listOf("40", "42", "44", "46"), 1,
        "Differences are 4, 6, 8, 10, so the next difference is 12. 30 + 12 = 42."),
    Question("Reasoning", "If CAT is coded as DBU by shifting every letter one step forward, how is DOG coded?", listOf("EPH", "EOH", "DPH", "FPI"), 0,
        "D→E, O→P, G→H, so DOG becomes EPH."),
    Question("English", "Choose the grammatically correct sentence.", listOf(
        "Neither of the boys have completed the work.",
        "Neither of the boys has completed the work.",
        "Neither of the boys are completed the work.",
        "Neither of the boys having completed the work."
    ), 1, "Neither is singular in this construction, so the correct verb is has.")
)

@Composable
fun App() {
    var screen by remember { mutableStateOf("home") }
    var selectedSubject by remember { mutableStateOf("All") }
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var answered by remember { mutableStateOf(false) }

    val filtered = questions.filter { selectedSubject == "All" || it.subject == selectedSubject }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF63D8A3),
            background = Color(0xFF101522),
            surface = Color(0xFF182131)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            when (screen) {
                "home" -> Home(
                    onStart = { subject ->
                        selectedSubject = subject
                        index = 0
                        score = 0
                        selected = -1
                        answered = false
                        screen = "quiz"
                    }
                )
                "quiz" -> {
                    if (index >= filtered.size) {
                        Result(score, filtered.size) { screen = "home" }
                    } else {
                        val q = filtered[index]
                        Quiz(
                            q = q,
                            number = index + 1,
                            total = filtered.size,
                            selected = selected,
                            answered = answered,
                            onOption = { choice ->
                                if (!answered) {
                                    selected = choice
                                    answered = true
                                    if (choice == q.answer) score++
                                }
                            },
                            onNext = {
                                index++
                                selected = -1
                                answered = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun Home(onStart: (String) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text("APTITUDE QUEST", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text("Noob → Pro", color = MaterialTheme.colorScheme.primary, fontSize = 20.sp)
        Text("SSC + Banking practice • Quant • Reasoning • English")
        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("LEVEL 1", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Build your basics and earn XP.")
                Text("🏆 XP 0     🔥 Streak 0")
            }
        }
        Text("Choose practice", fontWeight = FontWeight.Bold, fontSize = 19.sp)
        listOf("All", "Quant", "Reasoning", "English").forEach { subject ->
            Button(
                onClick = { onStart(subject) },
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(if (subject == "All") "Mixed Quiz" else subject, fontSize = 17.sp)
            }
        }
        Spacer(Modifier.weight(1f))
        Text("More visual reasoning puzzles and levels will be added next.", fontSize = 13.sp)
    }
}

@Composable
fun Quiz(
    q: Question,
    number: Int,
    total: Int,
    selected: Int,
    answered: Boolean,
    onOption: (Int) -> Unit,
    onNext: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("${q.subject}  •  Question $number/$total", fontWeight = FontWeight.Bold)
        LinearProgressIndicator(
            progress = { number.toFloat() / total },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        Card(shape = RoundedCornerShape(20.dp)) {
            Text(q.text, Modifier.padding(22.dp), fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        q.options.forEachIndexed { i, option ->
            val bg = when {
                !answered -> MaterialTheme.colorScheme.surfaceVariant
                i == q.answer -> Color(0xFF245C46)
                i == selected -> Color(0xFF6A3030)
                else -> MaterialTheme.colorScheme.surfaceVariant
            }
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onOption(i) },
                shape = RoundedCornerShape(15.dp),
                colors = CardDefaults.cardColors(containerColor = bg)
            ) {
                Text("${'A' + i}.  $option", Modifier.padding(18.dp), fontSize = 17.sp)
            }
        }
        if (answered) {
            Card(shape = RoundedCornerShape(15.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(if (selected == q.answer) "Correct! +XP" else "Keep going!", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(q.explanation)
                }
            }
            Button(onClick = onNext, modifier = Modifier.fillMaxWidth()) {
                Text("Next Question")
            }
        }
    }
}

@Composable
fun Result(score: Int, total: Int, onHome: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("LEVEL COMPLETE", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(20.dp))
        Text("$score / $total", fontSize = 52.sp, fontWeight = FontWeight.Bold)
        Text("Accuracy: ${if (total == 0) 0 else score * 100 / total}%")
        Spacer(Modifier.height(28.dp))
        Button(onClick = onHome, modifier = Modifier.fillMaxWidth()) {
            Text("Back to Home")
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
