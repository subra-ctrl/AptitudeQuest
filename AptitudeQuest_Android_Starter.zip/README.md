# Aptitude Quest — Noob → Pro

Android starter app for SSC + Banking practice.

Subjects:
- Quantitative Aptitude
- Reasoning
- English

Current build:
- Level 1
- Mixed/subject quiz
- Score and accuracy
- Answer explanations
- Dark game-style UI
- Native Android + Jetpack Compose

Open this project in Android Studio and run it on an Android phone/emulator.

Next planned modules:
1. XP, coins and streak persistence
2. Level unlocking: Noob → Beginner → Intermediate → Advanced → Pro
3. Timer and negative marking
4. Larger offline question bank
5. Visual reasoning questions with diagrams/images
6. Topic-wise performance tracking
