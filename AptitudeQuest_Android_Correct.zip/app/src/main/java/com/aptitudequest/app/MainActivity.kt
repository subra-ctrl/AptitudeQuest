package com.aptitudequest.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Q(val s:String,val q:String,val o:List<String>,val a:Int,val e:String)
val qs=listOf(
 Q("Quant","What is 25% of 240?",listOf("40","50","60","80"),2,"25% = 1/4, so 240 ÷ 4 = 60."),
 Q("Quant","A number increases from 200 to 250. What is the percentage increase?",listOf("20%","25%","30%","50%"),1,"Increase = 50; 50/200 × 100 = 25%."),
 Q("Reasoning","Find the next number: 2, 6, 12, 20, 30, ?",listOf("36","40","42","44"),2,"Differences are 4, 6, 8, 10, so next is 12. Answer = 42."),
 Q("Reasoning","If CAT is coded as DBU, how is DOG coded?",listOf("EPH","EOG","FPH","DPG"),0,"Each letter moves one step forward."),
 Q("English","Choose the grammatically correct sentence.",listOf("Neither of the boys have completed the work.","Neither of the boys has completed the work.","Neither of the boys are completed the work.","Neither boys has completed the work."),1,"Neither is singular, so 'has' is correct.")
)
@Composable fun App(){
 var sub by remember{mutableStateOf("All")}; var i by remember{mutableIntStateOf(0)}; var score by remember{mutableIntStateOf(0)}; var sel by remember{mutableIntStateOf(-1)}; var done by remember{mutableStateOf(false)}
 val list=if(sub=="All") qs else qs.filter{it.s==sub}
 MaterialTheme { Surface(Modifier.fillMaxSize()){ Column(Modifier.padding(24.dp)){
  if(done){Text("Level Complete!",style=MaterialTheme.typography.headlineMedium);Text("Score: $score / ${list.size}");Text("Accuracy: ${if(list.isEmpty())0 else score*100/list.size}%");Spacer(Modifier.height(20.dp));Button({i=0;score=0;sel=-1;done=false}){Text("Play Again")}}
  else {Text("APTITUDE QUEST",style=MaterialTheme.typography.headlineMedium);Text("Noob → Pro • SSC + Banking");Spacer(Modifier.height(16.dp));Row{listOf("All","Quant","Reasoning","English").forEach{OutlinedButton({sub=it;i=0;score=0;sel=-1}){Text(it)}}};Spacer(Modifier.height(20.dp));val x=list[i];Text("${x.s} • Question ${i+1}/${list.size}");Spacer(Modifier.height(12.dp));Text(x.q,style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(12.dp));x.o.forEachIndexed{n,o->Button({if(sel<0){sel=n;if(n==x.a)score++}},Modifier.fillMaxWidth().padding(3.dp),enabled=sel<0){Text(o)}};if(sel>=0){Text(if(sel==x.a)"Correct! 🎉" else "Incorrect");Text(x.e);Button({if(i==list.lastIndex)done=true else{i++;sel=-1}}){Text(if(i==list.lastIndex)"Finish" else "Next")}}}
 }}}
}
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
